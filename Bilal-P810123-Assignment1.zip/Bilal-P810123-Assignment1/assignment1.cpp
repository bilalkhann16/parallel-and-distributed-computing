#include <iostream>
#include <omp.h>
#include <time.h>
#include <algorithm>
#include <chrono>
using namespace std;

// random int generator
void populate(int a[], int n){
    cout<< "Populating the randoms"<<endl;
    for(int i = 0; i < n; i++){
        a[i] = rand() %10 +1;
    }
}
void oddEvenSort(int arr[], int n){
    bool isSorted = false;
        while (!isSorted){
        isSorted = true;
        for (int i=1; i<=n-2; i=i+2) {
            if (arr[i] > arr[i+1]) {
                cout<<"Swapping "<<arr[i]<<" and "<<arr[i+1]<<endl;
                swap(arr[i], arr[i+1]);
                isSorted = false;
            }
        }
        for (int i=0; i<=n-2; i=i+2) {
            if (arr[i] > arr[i+1]) {
                cout<<"Swapping "<<arr[i]<<" and "<<arr[i+1]<<endl;
                swap(arr[i], arr[i+1]);
                isSorted = false;
            }
        }
        }
    return;
}


int main(int argc, char *argv[])
{
// int n = atoi(argv[1]);
int n;
cout<< "Hello, User. Pls input the the length of array: ";
cin>>n;

int *arr = new int(n);
populate(arr, n); // Step 1: create this function
for(int i = 0; i < n; i++){
        cout<<arr[i]<<" ";
    }

// Step 2: Write code to start counting Time
auto start = chrono::steady_clock::now();

// Step 4: Parallelize this code.
omp_set_num_threads(5);
#pragma omp parallel
oddEvenSort(arr, n);

// Step 3: Write code to end counting Time and display it
auto end = chrono::steady_clock::now();
auto diff = end - start;
cout <<"Total time taken: "<< chrono::duration <double, milli> (diff).count() << " ms" << endl;

return 0;
}